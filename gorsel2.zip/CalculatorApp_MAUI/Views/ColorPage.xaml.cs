using Microsoft.Maui.Controls;
using System;

namespace CalculatorApp_MAUI.Views
{
    public partial class ColorPage : ContentPage
    {
        public ColorPage()
        {
            InitializeComponent();
            // Varsay�lan de�erleri ayarla
            redSlider.Value = 0;
            greenSlider.Value = 0;
            blueSlider.Value = 0;
            UpdateColor();
        }

        private void OnColorSliderValueChanged(object sender, ValueChangedEventArgs e)
        {
            redLabel.Text = $"Red: {Convert.ToInt32(redSlider.Value)}";
            greenLabel.Text = $"Green: {Convert.ToInt32(greenSlider.Value)}";
            blueLabel.Text = $"Blue: {Convert.ToInt32(blueSlider.Value)}";
            UpdateColor();
        }

        private void UpdateColor()
        {
            // Slider'lardan RGB de�erlerini al
            int r = Convert.ToInt32(redSlider.Value);
            int g = Convert.ToInt32(greenSlider.Value);
            int b = Convert.ToInt32(blueSlider.Value);

            // Arka plan rengini g�ncelle
            Color newColor = Color.FromRgb(r, g, b);
            this.BackgroundColor = newColor;

            // HEX kodunu hesapla ve etikete yaz
            hexLabel.Text = $"#{r:X2}{g:X2}{b:X2}";

            // Daha do�ru kontrast kontrol� (W3C luminance y�ntemi)
            double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
            hexLabel.TextColor = luminance < 140 ? Colors.White : Colors.Black;

            redLabel.TextColor = luminance < 140 ? Colors.White : Colors.Black;
            greenLabel.TextColor = luminance < 140 ? Colors.White : Colors.Black;
            blueLabel.TextColor = luminance < 140 ? Colors.White : Colors.Black;

        }

        private async void OnCopyClicked(object sender, EventArgs e)
        {
            string renkKodu = hexLabel.Text;
            await Clipboard.SetTextAsync(renkKodu);
            await DisplayAlert("Kopyaland�", $"{renkKodu} panoya kopyaland�.", "OK");
        }

        private void OnRandomColorClicked(object sender, EventArgs e)
        {
            var rand = new Random();
            redSlider.Value = rand.Next(0, 256);
            greenSlider.Value = rand.Next(0, 256);
            blueSlider.Value = rand.Next(0, 256);
        }
    }
}
