using Microsoft.Maui.Controls;

namespace CalculatorApp_MAUI.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            // Sayfa a��ld���nda animasyon efektleri
            await this.FadeTo(0, 0); // ilk g�r�nmesin
            await this.FadeTo(1, 800, Easing.CubicIn); // yava��a g�r�n

            // Alternatif olarak profil resmi d�nebilir veya scale animasyonu verilebilir
        }

    }
}
