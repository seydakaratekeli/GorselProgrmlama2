using Microsoft.Maui.Controls;
using System;

namespace CalculatorApp_MAUI.Views
{
    public partial class BmiPage : ContentPage
    {
        public BmiPage()
        {
            InitializeComponent();
            // Varsay�lan de�erleri ayarla
            weightSlider.Value = 70;
            heightSlider.Value = 170;

            // Sayfa a��l�r a��lmaz BMI hesapla
            CalculateBmi();
        }

        // Her iki slider'�n de�erleri de�i�ti�inde tetiklenir
        private void OnSliderValueChanged(object sender, ValueChangedEventArgs e)
        {
            // Etiketleri g�ncelle
            weightLabel.Text = $"Kilo: {Convert.ToInt32(weightSlider.Value)} kg";
            heightLabel.Text = $"Boy: {Convert.ToInt32(heightSlider.Value)} cm";

            // BMI'yi yeniden hesapla
            CalculateBmi();
        }

        // VK� hesaplama ve duruma g�re geri bildirim sa�lama
        private void CalculateBmi()
        {
            double weight = weightSlider.Value;
            double heightCm = heightSlider.Value;
            double heightM = heightCm / 100;
            double bmi = weight / (heightM * heightM);

            // VK� de�eri g�ster
            bmiResultLabel.Text = $"VK�: {bmi:F2}";

            // Duruma g�re a��klama ve renk
            string status;
            Color color;

            if (bmi < 16)
            {
                status = "�leri D�zeyde Zay�f";
                color = Colors.Blue;
            }
            else if (bmi < 17)
            {
                status = "Orta D�zeyde Zay�f";
                color = Colors.SkyBlue;
            }
            else if (bmi < 18.5)
            {
                status = "Hafif D�zeyde Zay�f";
                color = Colors.LightBlue;
            }
            else if (bmi < 25)
            {
                status = "Normal Kilolu";
                color = Colors.Green;
            }
            else if (bmi < 30)
            {
                status = "Hafif �i�man / Fazla Kilolu";
                color = Colors.Orange;
            }
            else if (bmi < 35)
            {
                status = "1. Derecede Obez";
                color = Colors.DarkOrange;
            }
            else if (bmi < 40)
            {
                status = "2. Derecede Obez";
                color = Colors.Red;
            }
            else
            {
                status = "3. Derecede Obez / Morbid Obez";
                color = Colors.DarkRed;
            }

            // BMI sonucu etiketi g�ncelle
            bmiResultLabel.Text += $"\nDurum: {status}";
            bmiResultLabel.TextColor = color;
        }

    }
}
