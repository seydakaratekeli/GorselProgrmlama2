﻿using Microsoft.Maui.Controls;
using System;

namespace CalculatorApp_MAUI.Views
{
    public partial class LoanPage : ContentPage
    {
        public LoanPage()
        {
            InitializeComponent();
        }

        private void OnTermSliderValueChanged(object sender, ValueChangedEventArgs e)
        {
            termLabel.Text = $"Vade: {Convert.ToInt32(e.NewValue)} ay";
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(amountEntry.Text) ||
                string.IsNullOrWhiteSpace(interestEntry.Text) ||
                creditTypePicker.SelectedIndex == -1)
            {
                DisplayAlert("Uyarı", "Lütfen tüm alanları doldurun.", "Tamam");
                return;
            }

            if (!double.TryParse(amountEntry.Text, out double principal) ||
                !double.TryParse(interestEntry.Text, out double interestRate))
            {
                DisplayAlert("Hata", "Geçerli sayılar girin.", "Tamam");
                return;
            }

            string creditType = creditTypePicker.SelectedItem.ToString();
            double bsmv = 0;
            double kkdf = 0;

            switch (creditType)
            {
                case "İhtiyaç Kredisi":
                    bsmv = 0.10;
                    kkdf = 0.15;
                    break;
                case "Taşıt Kredisi":
                    bsmv = 0.05;
                    kkdf = 0.15;
                    break;
                case "Konut Kredisi":
                    bsmv = 0;
                    kkdf = 0;
                    break;
                case "Ticari Kredi":
                    bsmv = 0.05;
                    kkdf = 0;
                    break;
            }

            int vade = (int)termSlider.Value;
            double oran = interestRate / 100; // örn: 1.5 -> 0.015

            // Toplam efektif faiz oranı: faiz + BSMV + KKDF
            double brutFaiz = (oran + (oran * bsmv) + (oran * kkdf));

            // Anüite (eşit taksit) formülü
            double taksit = (Math.Pow(1 + brutFaiz, vade) * brutFaiz) / (Math.Pow(1 + brutFaiz, vade) - 1) * principal;
           
            double toplam = taksit * vade;
           
            double toplamFaiz = toplam - principal;

            resultLabel.Text = $"Aylık Taksit: {taksit:F2} ₺\n" +
                               $"Toplam Geri Ödeme: {toplam:F2} ₺\n" +
                               $"Toplam Faiz: {toplamFaiz:F2} ₺";
        }
    }
}
